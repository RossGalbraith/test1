﻿namespace Pingpong
{
    partial class racingMotoEN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(racingMotoEN));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.highScore = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.linie1 = new System.Windows.Forms.PictureBox();
            this.linie2 = new System.Windows.Forms.PictureBox();
            this.linie3 = new System.Windows.Forms.PictureBox();
            this.linie4 = new System.Windows.Forms.PictureBox();
            this.linie5 = new System.Windows.Forms.PictureBox();
            this.linie6 = new System.Windows.Forms.PictureBox();
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.linie7 = new System.Windows.Forms.PictureBox();
            this.linie8 = new System.Windows.Forms.PictureBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.benzina1 = new System.Windows.Forms.PictureBox();
            this.benzina2 = new System.Windows.Forms.PictureBox();
            this.benzina3 = new System.Windows.Forms.PictureBox();
            this.bomba1 = new System.Windows.Forms.PictureBox();
            this.bomba2 = new System.Windows.Forms.PictureBox();
            this.bomba3 = new System.Windows.Forms.PictureBox();
            this.stea = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.score5 = new System.Windows.Forms.Label();
            this.score4 = new System.Windows.Forms.Label();
            this.score3 = new System.Windows.Forms.Label();
            this.score2 = new System.Windows.Forms.Label();
            this.score1 = new System.Windows.Forms.Label();
            this.scoreBox = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.linie1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.benzina1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.benzina2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.benzina3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bomba1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bomba2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bomba3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stea)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(210, 287);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(70, 113);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 1;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 3;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(135, 440);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(30, 80);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseDown);
            this.pictureBox3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseMove);
            this.pictureBox3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Silver;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.toolStripMenuItem1,
            this.highScore});
            this.menuStrip1.Location = new System.Drawing.Point(0, 538);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.newGameToolStripMenuItem.Text = "Start";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.newGameToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "Exit";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // highScore
            // 
            this.highScore.Name = "highScore";
            this.highScore.Size = new System.Drawing.Size(77, 20);
            this.highScore.Text = "High Score";
            this.highScore.Click += new System.EventHandler(this.highScore_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(182, 540);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Score : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Location = new System.Drawing.Point(-4, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "label2";
            // 
            // linie1
            // 
            this.linie1.BackColor = System.Drawing.Color.White;
            this.linie1.Location = new System.Drawing.Point(97, 27);
            this.linie1.Name = "linie1";
            this.linie1.Size = new System.Drawing.Size(6, 70);
            this.linie1.TabIndex = 6;
            this.linie1.TabStop = false;
            // 
            // linie2
            // 
            this.linie2.BackColor = System.Drawing.Color.White;
            this.linie2.Location = new System.Drawing.Point(97, 160);
            this.linie2.Name = "linie2";
            this.linie2.Size = new System.Drawing.Size(6, 70);
            this.linie2.TabIndex = 7;
            this.linie2.TabStop = false;
            // 
            // linie3
            // 
            this.linie3.BackColor = System.Drawing.Color.White;
            this.linie3.Location = new System.Drawing.Point(97, 290);
            this.linie3.Name = "linie3";
            this.linie3.Size = new System.Drawing.Size(6, 70);
            this.linie3.TabIndex = 8;
            this.linie3.TabStop = false;
            // 
            // linie4
            // 
            this.linie4.BackColor = System.Drawing.Color.White;
            this.linie4.Location = new System.Drawing.Point(97, 429);
            this.linie4.Name = "linie4";
            this.linie4.Size = new System.Drawing.Size(6, 70);
            this.linie4.TabIndex = 9;
            this.linie4.TabStop = false;
            // 
            // linie5
            // 
            this.linie5.BackColor = System.Drawing.Color.White;
            this.linie5.Location = new System.Drawing.Point(197, 27);
            this.linie5.Name = "linie5";
            this.linie5.Size = new System.Drawing.Size(6, 70);
            this.linie5.TabIndex = 10;
            this.linie5.TabStop = false;
            // 
            // linie6
            // 
            this.linie6.BackColor = System.Drawing.Color.White;
            this.linie6.Location = new System.Drawing.Point(197, 160);
            this.linie6.Name = "linie6";
            this.linie6.Size = new System.Drawing.Size(6, 70);
            this.linie6.TabIndex = 11;
            this.linie6.TabStop = false;
            // 
            // timer4
            // 
            this.timer4.Interval = 1;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // linie7
            // 
            this.linie7.BackColor = System.Drawing.Color.White;
            this.linie7.Location = new System.Drawing.Point(197, 290);
            this.linie7.Name = "linie7";
            this.linie7.Size = new System.Drawing.Size(6, 70);
            this.linie7.TabIndex = 12;
            this.linie7.TabStop = false;
            // 
            // linie8
            // 
            this.linie8.BackColor = System.Drawing.Color.White;
            this.linie8.Location = new System.Drawing.Point(197, 429);
            this.linie8.Name = "linie8";
            this.linie8.Size = new System.Drawing.Size(6, 70);
            this.linie8.TabIndex = 13;
            this.linie8.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(41, 516);
            this.progressBar1.Maximum = 101;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(190, 19);
            this.progressBar1.TabIndex = 14;
            // 
            // timer5
            // 
            this.timer5.Interval = 200;
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // benzina1
            // 
            this.benzina1.Image = ((System.Drawing.Image)(resources.GetObject("benzina1.Image")));
            this.benzina1.Location = new System.Drawing.Point(30, 246);
            this.benzina1.Name = "benzina1";
            this.benzina1.Size = new System.Drawing.Size(35, 35);
            this.benzina1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.benzina1.TabIndex = 15;
            this.benzina1.TabStop = false;
            // 
            // benzina2
            // 
            this.benzina2.Image = ((System.Drawing.Image)(resources.GetObject("benzina2.Image")));
            this.benzina2.Location = new System.Drawing.Point(130, 246);
            this.benzina2.Name = "benzina2";
            this.benzina2.Size = new System.Drawing.Size(35, 35);
            this.benzina2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.benzina2.TabIndex = 16;
            this.benzina2.TabStop = false;
            // 
            // benzina3
            // 
            this.benzina3.Image = ((System.Drawing.Image)(resources.GetObject("benzina3.Image")));
            this.benzina3.Location = new System.Drawing.Point(230, 246);
            this.benzina3.Name = "benzina3";
            this.benzina3.Size = new System.Drawing.Size(35, 35);
            this.benzina3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.benzina3.TabIndex = 17;
            this.benzina3.TabStop = false;
            // 
            // bomba1
            // 
            this.bomba1.Image = ((System.Drawing.Image)(resources.GetObject("bomba1.Image")));
            this.bomba1.Location = new System.Drawing.Point(30, 185);
            this.bomba1.Name = "bomba1";
            this.bomba1.Size = new System.Drawing.Size(35, 35);
            this.bomba1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bomba1.TabIndex = 18;
            this.bomba1.TabStop = false;
            // 
            // bomba2
            // 
            this.bomba2.Image = ((System.Drawing.Image)(resources.GetObject("bomba2.Image")));
            this.bomba2.Location = new System.Drawing.Point(130, 185);
            this.bomba2.Name = "bomba2";
            this.bomba2.Size = new System.Drawing.Size(35, 35);
            this.bomba2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bomba2.TabIndex = 19;
            this.bomba2.TabStop = false;
            // 
            // bomba3
            // 
            this.bomba3.Image = ((System.Drawing.Image)(resources.GetObject("bomba3.Image")));
            this.bomba3.Location = new System.Drawing.Point(230, 185);
            this.bomba3.Name = "bomba3";
            this.bomba3.Size = new System.Drawing.Size(35, 35);
            this.bomba3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bomba3.TabIndex = 20;
            this.bomba3.TabStop = false;
            // 
            // stea
            // 
            this.stea.Image = ((System.Drawing.Image)(resources.GetObject("stea.Image")));
            this.stea.Location = new System.Drawing.Point(130, 109);
            this.stea.Name = "stea";
            this.stea.Size = new System.Drawing.Size(35, 35);
            this.stea.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stea.TabIndex = 21;
            this.stea.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Controls.Add(this.exit);
            this.panel1.Controls.Add(this.score5);
            this.panel1.Controls.Add(this.score4);
            this.panel1.Controls.Add(this.score3);
            this.panel1.Controls.Add(this.score2);
            this.panel1.Controls.Add(this.score1);
            this.panel1.Controls.Add(this.scoreBox);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(280, 204);
            this.panel1.TabIndex = 22;
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(81, 150);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 6;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // score5
            // 
            this.score5.AutoSize = true;
            this.score5.Location = new System.Drawing.Point(27, 131);
            this.score5.Name = "score5";
            this.score5.Size = new System.Drawing.Size(16, 13);
            this.score5.TabIndex = 5;
            this.score5.Text = "5:";
            // 
            // score4
            // 
            this.score4.AutoSize = true;
            this.score4.Location = new System.Drawing.Point(27, 109);
            this.score4.Name = "score4";
            this.score4.Size = new System.Drawing.Size(16, 13);
            this.score4.TabIndex = 4;
            this.score4.Text = "4:";
            // 
            // score3
            // 
            this.score3.AutoSize = true;
            this.score3.Location = new System.Drawing.Point(27, 84);
            this.score3.Name = "score3";
            this.score3.Size = new System.Drawing.Size(16, 13);
            this.score3.TabIndex = 3;
            this.score3.Text = "3:";
            // 
            // score2
            // 
            this.score2.AutoSize = true;
            this.score2.Location = new System.Drawing.Point(27, 58);
            this.score2.Name = "score2";
            this.score2.Size = new System.Drawing.Size(16, 13);
            this.score2.TabIndex = 2;
            this.score2.Text = "2:";
            // 
            // score1
            // 
            this.score1.AutoSize = true;
            this.score1.Location = new System.Drawing.Point(27, 33);
            this.score1.Name = "score1";
            this.score1.Size = new System.Drawing.Size(16, 13);
            this.score1.TabIndex = 1;
            this.score1.Text = "1:";
            // 
            // scoreBox
            // 
            this.scoreBox.AutoSize = true;
            this.scoreBox.Location = new System.Drawing.Point(109, 9);
            this.scoreBox.Name = "scoreBox";
            this.scoreBox.Size = new System.Drawing.Size(65, 13);
            this.scoreBox.TabIndex = 0;
            this.scoreBox.Text = "High Scores";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(205, 538);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Return";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // racingMotoEN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(284, 562);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.linie1);
            this.Controls.Add(this.linie5);
            this.Controls.Add(this.linie6);
            this.Controls.Add(this.linie2);
            this.Controls.Add(this.linie3);
            this.Controls.Add(this.linie7);
            this.Controls.Add(this.linie4);
            this.Controls.Add(this.linie8);
            this.Controls.Add(this.benzina3);
            this.Controls.Add(this.benzina2);
            this.Controls.Add(this.benzina1);
            this.Controls.Add(this.bomba1);
            this.Controls.Add(this.bomba2);
            this.Controls.Add(this.bomba3);
            this.Controls.Add(this.stea);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "racingMotoEN";
            this.Text = "Racing Moto by Bogdan";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.linie1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linie8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.benzina1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.benzina2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.benzina3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bomba1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bomba2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bomba3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stea)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highScore;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox linie1;
        private System.Windows.Forms.PictureBox linie2;
        private System.Windows.Forms.PictureBox linie3;
        private System.Windows.Forms.PictureBox linie4;
        private System.Windows.Forms.PictureBox linie5;
        private System.Windows.Forms.PictureBox linie6;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.PictureBox linie7;
        private System.Windows.Forms.PictureBox linie8;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.PictureBox benzina1;
        private System.Windows.Forms.PictureBox benzina2;
        private System.Windows.Forms.PictureBox benzina3;
        private System.Windows.Forms.PictureBox bomba1;
        private System.Windows.Forms.PictureBox bomba2;
        private System.Windows.Forms.PictureBox bomba3;
        private System.Windows.Forms.PictureBox stea;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label score5;
        private System.Windows.Forms.Label score4;
        private System.Windows.Forms.Label score3;
        private System.Windows.Forms.Label score2;
        private System.Windows.Forms.Label score1;
        private System.Windows.Forms.Label scoreBox;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button button1;
        private System.IO.Ports.SerialPort serialPort1;
    }
}

