﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Pingpong
{
    public partial class racingMoto : Form
    {
        public racingMoto()
        {
            InitializeComponent();
            panel1.Visible = false;

            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            label2.Visible = false;
            benzina1.Visible = false;
            benzina2.Visible = false;
            benzina3.Visible = false;
            progressBar1.Value = 100;
            progressBar1.Visible = false;
            benzina1.Location = new Point(400, 0);
            benzina2.Location = new Point(400, 0);
            benzina3.Location = new Point(400, 0);
            bomba1.Visible = false;
            bomba2.Visible = false;
            bomba3.Visible = false;
            bomba1.Location = new Point(400, 0);
            bomba2.Location = new Point(400, 0);
            bomba3.Location = new Point(400, 0);
            stea.Location = new Point(400, 0);
            stea.Visible = false;
            label2.Text = "Control the motorcycle lasting as long as you can!" + Environment.NewLine + "Use the colour blocks to go up,down left or right" + Environment.NewLine + "Avoid cars and bombs while collecting fuel and stars.";
        }
        bool drag = false;
        int mousex, mousey;
        int scor, t = 0, d = 0, can1 = 17, can2 = 36, can3 = 55, bom1 = 7, bom2 = 25, bom3 = 68, ste = 2;
        Random nr = new Random();
        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            mousex = Cursor.Position.X - pictureBox3.Left;
            mousey = Cursor.Position.Y - pictureBox3.Top;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag == true)
                pictureBox3.Location = new Point(Cursor.Position.X - mousex, Cursor.Position.Y - mousey);
            if (pictureBox3.Location.X < 0 || pictureBox3.Location.X > 254 || pictureBox3.Location.Y < 5 || pictureBox3.Location.Y > 500)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;
            

                MessageBox.Show("You fell ! You score is: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;
                

                MessageBox.Show("You hit the car ! Your score is: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;
                

                MessageBox.Show("You hit the car! You score is: " + scor.ToString());
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void back_Click_1(object sender, EventArgs e)
        {
            Menu f2 = new Menu();
            f2.RefTopingPong = this;
            this.Visible = false;
            f2.Show();
        }

       

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            timer4.Enabled = true;
            timer5.Enabled = true;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            label1.Visible = true;
            pictureBox1.Location = new Point(0, 27);
            pictureBox2.Location = new Point(202, 287);
            pictureBox3.Location = new Point(120, 440);
            benzina1.Visible = false;
            benzina2.Visible = false;
            benzina3.Visible = false;
            scor = 0;
            d = 0;
            t = 0;
 
            bomba1.Location = new Point(400, 0);
            bomba2.Location = new Point(400, 0);
            bomba3.Location = new Point(400, 0);
            progressBar1.Visible = true;
            progressBar1.Value = 100;
            drag = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y + 2);
            int n = nr.Next(1, 4);
            if (pictureBox1.Location.Y > 480 && n==1)
            {
                pictureBox1.Location = new Point(12, 0);
            }
            if (pictureBox1.Location.Y > 480 && n == 2)
            {
                pictureBox1.Location = new Point(102, 0);
            }
            if (pictureBox1.Location.Y > 480 && n == 3)
            {
                pictureBox1.Location = new Point(192, 0);
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random mr = new Random();
            pictureBox2.Location = new Point(pictureBox2.Location.X, pictureBox2.Location.Y + 2);
            int m = mr.Next(1, 4);
            if (pictureBox2.Location.Y > 480 && m == 1)
            {
                pictureBox2.Location = new Point(12, 0);
            }
            if (pictureBox2.Location.Y > 480 && m == 2)
            {
                pictureBox2.Location = new Point(102, 0);
            }
            if (pictureBox2.Location.Y > 480 && m == 3)
            {
                pictureBox2.Location = new Point(192, 0);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
           
            scor = scor + 1;
            label1.Text = "Score : " + scor.ToString();
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;
               

                MessageBox.Show("You hit the car! Your score is: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;
                

                MessageBox.Show("You hit the car! Your final score is " + scor.ToString());
            }
           
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y - 30);
            if (e.KeyCode == Keys.Down)
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y + 30);
            if (e.KeyCode == Keys.Left)
                pictureBox3.Location = new Point(pictureBox3.Location.X - 100, pictureBox3.Location.Y);
            if (e.KeyCode == Keys.Right)
                pictureBox3.Location = new Point(pictureBox3.Location.X + 100, pictureBox3.Location.Y);
            if (e.KeyCode == Keys.L)
            {
                panel1.Visible = false;
                timer1.Enabled = true;
                timer2.Enabled = true;
                timer3.Enabled = true;
                timer4.Enabled = true;
                timer5.Enabled = true;
                pictureBox1.Visible = true;
                pictureBox2.Visible = true;
                pictureBox3.Visible = true;
                label1.Visible = true;
                pictureBox1.Location = new Point(0, 27);
                pictureBox2.Location = new Point(202, 287);
                pictureBox3.Location = new Point(120, 440);
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                scor = 0;
                d = 0;
                t = 0;
                
                bomba1.Location = new Point(400, 0);
                bomba2.Location = new Point(400, 0);
                bomba3.Location = new Point(400, 0);
                progressBar1.Visible = true;
                progressBar1.Value = 100;
                drag = false;
            }
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                progressBar1.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                stea.Visible = false;
               

                MessageBox.Show("You hit the car! Your score is: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                progressBar1.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                stea.Visible = false;
               

                MessageBox.Show("You hit the car! Your score is: " + scor.ToString());
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            t++;
            if (t % 2 != 0)
            {
                label2.Visible = true;
            }
            if (t % 2 == 0)
            {
                label2.Visible = false;
            }
        }

        

        
        private void timer4_Tick(object sender, EventArgs e)
        {
            d++;
            if (d % 2 == 0)
            {
                linie1.Visible = true;
                linie3.Visible = true;
                linie5.Visible = false;
                linie2.Visible = false;
                linie4.Visible = false;
                linie6.Visible = true;
                linie7.Visible = false;
                linie8.Visible = true;
            }
            if (d % 2 != 0)
            {
                linie1.Visible = false;
                linie3.Visible = false;
                linie5.Visible = true;
                linie2.Visible = true;
                linie4.Visible = true;
                linie6.Visible = false;
                linie7.Visible = true;
                linie8.Visible = false;
            }
                
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            progressBar1.Value = progressBar1.Value - 1;
            if (progressBar1.Value <= 0)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;
               

                MessageBox.Show("You ran out of fuel! Your score is: " + scor.ToString());
            }
            Random benz = new Random();
            int canistra = benz.Next(1, 70);
            if (canistra == can1)
            {
                benzina1.Visible = true;
                benzina1.Location = new Point(27, 246);
            }
            if (canistra == can2)
            {
                benzina2.Visible = true;
                benzina2.Location = new Point(120, 246);
            }
            if (canistra == can3)
            {
                benzina3.Visible = true;
                benzina3.Location = new Point(231, 246);
            }
            if (canistra == bom1)
            {
                bomba1.Visible = true;
                bomba1.Location = new Point(27, 185);
            }
            if (canistra == bom2)
            {
                bomba2.Visible = true;
                bomba2.Location = new Point(120, 185);
            }
            if (canistra == bom3)
            {
                bomba3.Visible = true;
                bomba3.Location = new Point(231, 185);
            }
            if (canistra == ste)
            {
                stea.Visible = true;
                stea.Location = new Point(120, 131);
            }
            if (pictureBox3.Bounds.Contains(benzina1.Location) || benzina1.Bounds.Contains(pictureBox3.Location))
            {
                int diferenta;
                diferenta = 100 - progressBar1.Value;
                if (diferenta <= 50)
                {
                    progressBar1.Value = progressBar1.Value + diferenta;
                }
                if (diferenta > 50)
                {
                    progressBar1.Value = progressBar1.Value + 50;
                }
                benzina1.Visible = false;
                benzina1.Location = new Point(400, 0);
            }
             if (pictureBox3.Bounds.Contains(benzina2.Location) || benzina2.Bounds.Contains(pictureBox3.Location))
            {
                int diferenta;
                diferenta = 100 - progressBar1.Value;
                if (diferenta <= 50)
                {
                    progressBar1.Value = progressBar1.Value + diferenta;
                }
                if (diferenta > 50)
                {
                    progressBar1.Value = progressBar1.Value + 50;
                }
                benzina2.Visible = false;
                benzina2.Location = new Point(400, 0);
            }
             if (pictureBox3.Bounds.Contains(benzina3.Location) || benzina3.Bounds.Contains(pictureBox3.Location))
             {
                 int diferenta;
                 diferenta = 100 - progressBar1.Value;
                 if (diferenta <= 50)
                 {
                     progressBar1.Value = progressBar1.Value + diferenta;
                 }
                 if (diferenta > 50)
                 {
                     progressBar1.Value = progressBar1.Value + 50;
                 }
                 benzina3.Visible = false;
                 benzina3.Location = new Point(400, 0);
             }
             if (pictureBox3.Bounds.Contains(stea.Location) || stea.Bounds.Contains(pictureBox3.Location))
             {
                 scor = scor + 1000;
                 stea.Visible = false;
                 stea.Location = new Point(400, 0);
             }
             if (pictureBox3.Bounds.Contains(bomba1.Location) || bomba1.Bounds.Contains(pictureBox3.Location) || pictureBox3.Bounds.Contains(bomba2.Location) || bomba2.Bounds.Contains(pictureBox3.Location) || pictureBox3.Bounds.Contains(bomba3.Location) || bomba3.Bounds.Contains(pictureBox3.Location))
             {
                 timer1.Enabled = false;
                 timer2.Enabled = false;
                 timer3.Enabled = false;
                 timer4.Enabled = false;
                 timer5.Enabled = false;
                 bomba1.Location = new Point(400, 0);
                 bomba2.Location = new Point(400, 0);
                 bomba3.Location = new Point(400, 0);
                 pictureBox3.Location = new Point(120, 440);
                 pictureBox1.Location = new Point(12, 27);
                 pictureBox2.Location = new Point(102, 27);
                 pictureBox1.Visible = false;
                 pictureBox2.Visible = false;
                 pictureBox3.Visible = false;
                 label1.Visible = false;
                 linie1.Visible = true;
                 linie2.Visible = true;
                 linie3.Visible = true;
                 linie4.Visible = true;
                 linie5.Visible = true;
                 linie6.Visible = true;
                 linie7.Visible = true;
                 linie8.Visible = true;
                 benzina1.Visible = false;
                 benzina2.Visible = false;
                 benzina3.Visible = false;
                 bomba1.Visible = false;
                 bomba2.Visible = false;
                 bomba3.Visible = false;
                 progressBar1.Visible = false;
                 stea.Visible = false;
                
                 MessageBox.Show("You hit a bomb! Your score is: " + scor.ToString());
             }
             if (bomba1.Visible == true)
             {
                 bomba2.Visible = false;
                 bomba3.Visible = false;
                 bomba2.Location = new Point(400, 0);
                 bomba3.Location = new Point(400, 0);
             }
             if (bomba2.Visible == true)
             {
                 bomba1.Visible = false;
                 bomba3.Visible = false;
                 bomba1.Location = new Point(400, 0);
                 bomba3.Location = new Point(400, 0);
             }
             if (bomba3.Visible == true)
             {
                 bomba1.Visible = false;
                 bomba2.Visible = false;
                 bomba1.Location = new Point(400, 0);
                 bomba2.Location = new Point(400, 0);
             }

        }
    }
}
