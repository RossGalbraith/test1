﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Threading;

namespace Pingpong
{
    public partial class Form1: Form
    {
        int distanceNumber;
        public Form1()
        {
            InitializeComponent();
            panel1.Visible = false;

            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            label2.Visible = false;
            benzina1.Visible = false;
            benzina2.Visible = false;
            benzina3.Visible = false;
            progressBar1.Value = 100;
            progressBar1.Visible = false;
            benzina1.Location = new Point(400, 0);
            benzina2.Location = new Point(400, 0);
            benzina3.Location = new Point(400, 0);
            bomba1.Visible = false;
            bomba2.Visible = false;
            bomba3.Visible = false;
            bomba1.Location = new Point(400, 0);
            bomba2.Location = new Point(400, 0);
            bomba3.Location = new Point(400, 0);
            stea.Location = new Point(400, 0);
            stea.Visible = false;
            label2.Text = "Contrôlez la moto aussi longtemps que vous" + Environment.NewLine + "le pouvez! Utilisez les blocs de" + Environment.NewLine + "couleur pour monter, descendre" + Environment.NewLine + "à gauche ou à droite Évitez les voitures et" + Environment.NewLine + "les bombes tout en collectant du carburant" + Environment.NewLine + "et des étoiles.";
        }
        bool drag = false;
        int mousex, mousey;
        int scor, t = 0, d = 0, can1 = 17, can2 = 36, can3 = 55, bom1 = 7, bom2 = 25, bom3 = 68, ste = 2;
        Random nr = new Random();
        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            mousex = Cursor.Position.X - pictureBox3.Left;
            mousey = Cursor.Position.Y - pictureBox3.Top;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag == true)
                pictureBox3.Location = new Point(Cursor.Position.X - mousex, Cursor.Position.Y - mousey);
            if (pictureBox3.Location.X < 0 || pictureBox3.Location.X > 254 || pictureBox3.Location.Y < 5 || pictureBox3.Location.Y > 500)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Tu sens ! Ton score est: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Vous frappez la voiture! Ton score est: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Vous frappez la voiture! Ton score est: " + scor.ToString());
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void toolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            Menu f2 = new Menu();
            f2.RefTopingPong = this;
            this.Visible = false;
            f2.Show();
        }

       
      

    
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }
        void colourSender(string[] args)
        {
            var ts = new ThreadStart(BackgroundMethod);
            var backgroundThread = new Thread(ts);
            backgroundThread.Start();
        }
        private  void BackgroundMethod()
        {
            // Background calculations here.
            int i = 0;
          
             if (i<1000)
            {
                serialPort1.WriteLine("h");
                Thread.Sleep(300);
                Console.WriteLine(i++);
            } 
           
            // End background calculations.
        }
        private void distanceSensor()
        {
            int i = 0;
            while (i < 10)
            {
                i++;


                serialPort1.WriteLine("g");
                string hi = Convert.ToString(serialPort1.ReadExisting());
                Int32.TryParse(hi, out distanceNumber);
                if (distanceNumber > 100)
                {
                    MessageBox.Show("STand Closer");
                    Console.WriteLine(distanceNumber);
                }

                Console.WriteLine(distanceNumber);

            }
        }
        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            timer4.Enabled = true;
            timer5.Enabled = true;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            label1.Visible = true;
            pictureBox1.Location = new Point(0, 27);
            pictureBox2.Location = new Point(202, 287);
            pictureBox3.Location = new Point(120, 440);
            benzina1.Visible = false;
            benzina2.Visible = false;
            benzina3.Visible = false;
            scor = 0;
            d = 0;
            t = 0;

            bomba1.Location = new Point(400, 0);
            bomba2.Location = new Point(400, 0);
            bomba3.Location = new Point(400, 0);
            progressBar1.Visible = true;
            progressBar1.Value = 100;
            drag = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y + 2);
            int n = nr.Next(1, 4);
            if (pictureBox1.Location.Y > 480 && n == 1)
            {
                pictureBox1.Location = new Point(12, 0);
            }
            if (pictureBox1.Location.Y > 480 && n == 2)
            {
                pictureBox1.Location = new Point(102, 0);
            }
            if (pictureBox1.Location.Y > 480 && n == 3)
            {
                pictureBox1.Location = new Point(192, 0);
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random mr = new Random();
            pictureBox2.Location = new Point(pictureBox2.Location.X, pictureBox2.Location.Y + 2);
            int m = mr.Next(1, 4);
            if (pictureBox2.Location.Y > 480 && m == 1)
            {
                pictureBox2.Location = new Point(12, 0);
            }
            if (pictureBox2.Location.Y > 480 && m == 2)
            {
                pictureBox2.Location = new Point(102, 0);
            }
            if (pictureBox2.Location.Y > 480 && m == 3)
            {
                pictureBox2.Location = new Point(192, 0);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {

            scor = scor + 1;
            label1.Text = "Score : " + scor.ToString();
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Vous frappez la voiture! Ton score est: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Vous frappez la voiture! Ton score est: " + scor.ToString());
            }

        }

        private void SetPlayerMovement()

        {
            string colourDirection = Convert.ToString(serialPort1.ReadExisting());
            Console.WriteLine(colourDirection);
            if (colourDirection == "red")
            {
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y - 30);
            }
            else if (colourDirection == "green")
            {
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y + 30);
            }
            else if (colourDirection == "White")
            {
                pictureBox3.Location = new Point(pictureBox3.Location.X - 100, pictureBox3.Location.Y);
            }
            else if (colourDirection == "blue")
            {
                pictureBox3.Location = new Point(pictureBox3.Location.X + 100, pictureBox3.Location.Y);
            }
            

        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y - 30);
            if (e.KeyCode == Keys.Down)
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y + 30);
            if (e.KeyCode == Keys.Left)
                pictureBox3.Location = new Point(pictureBox3.Location.X - 100, pictureBox3.Location.Y);
            if (e.KeyCode == Keys.Right)
                pictureBox3.Location = new Point(pictureBox3.Location.X + 100, pictureBox3.Location.Y);
            if (e.KeyCode == Keys.L)
            {
                panel1.Visible = false;
                timer1.Enabled = true;
                timer2.Enabled = true;
                timer3.Enabled = true;
                timer4.Enabled = true;
                timer5.Enabled = true;
                pictureBox1.Visible = true;
                pictureBox2.Visible = true;
                pictureBox3.Visible = true;
                label1.Visible = true;
                pictureBox1.Location = new Point(0, 27);
                pictureBox2.Location = new Point(202, 287);
                pictureBox3.Location = new Point(120, 440);
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                scor = 0;
                d = 0;
                t = 0;
                serialPort1.WriteLine("h");
                SetPlayerMovement();
                bomba1.Location = new Point(400, 0);
                bomba2.Location = new Point(400, 0);
                bomba3.Location = new Point(400, 0);
                progressBar1.Visible = true;
                progressBar1.Value = 100;
                drag = false;
            }
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                progressBar1.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Vous frappez la voiture! Ton score est: " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                progressBar1.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Vous frappez la voiture! Ton score est:" + scor.ToString());
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            t++;
            if (t % 2 != 0)
            {
                label2.Visible = true;
            }
            if (t % 2 == 0)
            {
                label2.Visible = false;
            }
        }

        private void SnakeForm_Load(object sender, EventArgs e)
        {
            //used to store the values read

            //Port name can be identified by checking the ports
            // section in Device Manager after connecting your device
            serialPort1.PortName = "COM3";
            //Provide the name of port to which device is connected
            //default values of hardware[check with device specification document]
            serialPort1.BaudRate = 9600;
            serialPort1.Parity = Parity.None;
            serialPort1.StopBits = StopBits.One;
            serialPort1.Handshake = Handshake.None;
            serialPort1.ReadTimeout = 100;
            serialPort1.WriteTimeout = 100;


            serialPort1.Open(); //opens the port
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);
            distanceSensor();
            serialPort1.WriteLine("h");
            serialPort1.WriteLine("f");

        }

        private string DispString;
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                string hello = (Convert.ToString(serialPort1.ReadExisting()));
                serialPort1.Write("h");
                SetPlayerMovement();
                Int32.TryParse(hello, out distanceNumber);
                Thread.Sleep(200);
                DispString = serialPort1.ReadExisting();

                //  Console.WriteLine(DispString);

            }
        }
        private void DisplayText(object sender, EventArgs e)
        {
            Console.WriteLine(DispString);
        }



    
    private void timer4_Tick(object sender, EventArgs e)
        {
            d++;
            if (d % 2 == 0)
            {
                linie1.Visible = true;
                linie3.Visible = true;
                linie5.Visible = false;
                linie2.Visible = false;
                linie4.Visible = false;
                linie6.Visible = true;
                linie7.Visible = false;
                linie8.Visible = true;
            }
            if (d % 2 != 0)
            {
                linie1.Visible = false;
                linie3.Visible = false;
                linie5.Visible = true;
                linie2.Visible = true;
                linie4.Visible = true;
                linie6.Visible = false;
                linie7.Visible = true;
                linie8.Visible = false;
            }

        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            progressBar1.Value = progressBar1.Value - 1;
            if (progressBar1.Value <= 0)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;


                MessageBox.Show("Vous avez manqué de carburant! Ton score est: " + scor.ToString());
            }
            Random benz = new Random();
            int canistra = benz.Next(1, 70);
            if (canistra == can1)
            {
                benzina1.Visible = true;
                benzina1.Location = new Point(27, 246);
            }
            if (canistra == can2)
            {
                benzina2.Visible = true;
                benzina2.Location = new Point(120, 246);
            }
            if (canistra == can3)
            {
                benzina3.Visible = true;
                benzina3.Location = new Point(231, 246);
            }
            if (canistra == bom1)
            {
                bomba1.Visible = true;
                bomba1.Location = new Point(27, 185);
            }
            if (canistra == bom2)
            {
                bomba2.Visible = true;
                bomba2.Location = new Point(120, 185);
            }
            if (canistra == bom3)
            {
                bomba3.Visible = true;
                bomba3.Location = new Point(231, 185);
            }
            if (canistra == ste)
            {
                stea.Visible = true;
                stea.Location = new Point(120, 131);
            }
            if (pictureBox3.Bounds.Contains(benzina1.Location) || benzina1.Bounds.Contains(pictureBox3.Location))
            {
                int diferenta;
                diferenta = 100 - progressBar1.Value;
                if (diferenta <= 50)
                {
                    progressBar1.Value = progressBar1.Value + diferenta;
                }
                if (diferenta > 50)
                {
                    progressBar1.Value = progressBar1.Value + 50;
                }
                benzina1.Visible = false;
                benzina1.Location = new Point(400, 0);
                {
                    

                    serialPort1.Write("e"); // sends face to rotate to happy 
                    Thread.Sleep(800);
                    serialPort1.Write("f"); // sends face to rotate back to normal
                    serialPort1.Close();
                    


                }
            }
            if (pictureBox3.Bounds.Contains(benzina2.Location) || benzina2.Bounds.Contains(pictureBox3.Location))
            {
                int diferenta;
                diferenta = 100 - progressBar1.Value;
                if (diferenta <= 50)
                {
                    progressBar1.Value = progressBar1.Value + diferenta;
                }
                if (diferenta > 50)
                {
                    progressBar1.Value = progressBar1.Value + 50;
                }
                benzina2.Visible = false;
                benzina2.Location = new Point(400, 0);
            }
            if (pictureBox3.Bounds.Contains(benzina3.Location) || benzina3.Bounds.Contains(pictureBox3.Location))
            {
                int diferenta;
                diferenta = 100 - progressBar1.Value;
                if (diferenta <= 50)
                {
                    progressBar1.Value = progressBar1.Value + diferenta;
                }
                if (diferenta > 50)
                {
                    progressBar1.Value = progressBar1.Value + 50;
                }
                benzina3.Visible = false;
                benzina3.Location = new Point(400, 0);
            }
            if (pictureBox3.Bounds.Contains(stea.Location) || stea.Bounds.Contains(pictureBox3.Location))
            {
                scor = scor + 1000;
                stea.Visible = false;
                stea.Location = new Point(400, 0);
            }
            if (pictureBox3.Bounds.Contains(bomba1.Location) || bomba1.Bounds.Contains(pictureBox3.Location) || pictureBox3.Bounds.Contains(bomba2.Location) || bomba2.Bounds.Contains(pictureBox3.Location) || pictureBox3.Bounds.Contains(bomba3.Location) || bomba3.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                timer5.Enabled = false;
                bomba1.Location = new Point(400, 0);
                bomba2.Location = new Point(400, 0);
                bomba3.Location = new Point(400, 0);
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                linie1.Visible = true;
                linie2.Visible = true;
                linie3.Visible = true;
                linie4.Visible = true;
                linie5.Visible = true;
                linie6.Visible = true;
                linie7.Visible = true;
                linie8.Visible = true;
                benzina1.Visible = false;
                benzina2.Visible = false;
                benzina3.Visible = false;
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba3.Visible = false;
                progressBar1.Visible = false;
                stea.Visible = false;

                MessageBox.Show("Vous frappez une bombe! Ton score est:" + scor.ToString());
            }
            if (bomba1.Visible == true)
            {
                bomba2.Visible = false;
                bomba3.Visible = false;
                bomba2.Location = new Point(400, 0);
                bomba3.Location = new Point(400, 0);
            }
            if (bomba2.Visible == true)
            {
                bomba1.Visible = false;
                bomba3.Visible = false;
                bomba1.Location = new Point(400, 0);
                bomba3.Location = new Point(400, 0);
            }
            if (bomba3.Visible == true)
            {
                bomba1.Visible = false;
                bomba2.Visible = false;
                bomba1.Location = new Point(400, 0);
                bomba2.Location = new Point(400, 0);
            }

        }
    }
}
